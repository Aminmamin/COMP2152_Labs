my_array = [1, 4, 7, 9]

# Question 3:


# Question 4:


# Question 5:
userAge = int(input("Enter your age: "))
userAge = userAge + 22
print("Now showing the shop items filtred by age:", userAge)
